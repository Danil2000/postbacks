package com.example.postbacks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostbacksApplication {

    public static void main(String[] args) {
        SpringApplication.run(PostbacksApplication.class, args);
    }

}
